var searchData=
[
  ['deleteevent_2ephp_457',['deleteevent.php',['../deleteevent_8php.html',1,'']]],
  ['deleteproduct_2ephp_458',['deleteproduct.php',['../deleteproduct_8php.html',1,'']]]
];
