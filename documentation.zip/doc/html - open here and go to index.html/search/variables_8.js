var searchData=
[
  ['std_5fline_5flength_889',['STD_LINE_LENGTH',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#acb0f453ae60fbe80a1221065af681cdf',1,'PHPMailer::PHPMailer::PHPMailer']]],
  ['stop_5fcontinue_890',['STOP_CONTINUE',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#afd1dcd18845b2e660d89726b20cd566e',1,'PHPMailer::PHPMailer::PHPMailer']]],
  ['stop_5fcritical_891',['STOP_CRITICAL',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#a9f37e989efccad58c693cdb0481c881f',1,'PHPMailer::PHPMailer::PHPMailer']]],
  ['stop_5fmessage_892',['STOP_MESSAGE',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#a18ac47549c5fb56a395b374b3c23f04f',1,'PHPMailer::PHPMailer::PHPMailer']]]
];
