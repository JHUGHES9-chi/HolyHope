var searchData=
[
  ['_5f_5fconstruct_544',['__construct',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_o_auth.html#ae8b8e1144b807ac13f20a916fd073b32',1,'PHPMailer\PHPMailer\OAuth\__construct()'],['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#a7dd626cfe1c29407eb37a713c631b5c7',1,'PHPMailer\PHPMailer\PHPMailer\__construct($exceptions=null)']]],
  ['_5f_5fdestruct_545',['__destruct',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#a421831a265621325e1fdd19aace0c758',1,'PHPMailer::PHPMailer::PHPMailer']]],
  ['_5fmime_5ftypes_546',['_mime_types',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#aef39e6995f3696cafdff7181f219e25f',1,'PHPMailer::PHPMailer::PHPMailer']]]
];
