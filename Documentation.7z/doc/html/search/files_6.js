var searchData=
[
  ['index_2ephp_470',['index.php',['../index_8php.html',1,'']]],
  ['inventory_2ephp_471',['inventory.php',['../inventory_8php.html',1,'']]]
];
