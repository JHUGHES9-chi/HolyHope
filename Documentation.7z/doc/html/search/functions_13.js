var searchData=
[
  ['validateaddress_727',['validateAddress',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#ab1751a18a24757fee7043fa3b055eb03',1,'PHPMailer::PHPMailer::PHPMailer']]],
  ['validateencoding_728',['validateEncoding',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#a7d4f6ab887b42e0771520d43468430ed',1,'PHPMailer::PHPMailer::PHPMailer']]],
  ['verify_729',['verify',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_s_m_t_p.html#a658837563d19069ce530b5665a28b71b',1,'PHPMailer::PHPMailer::SMTP']]]
];
