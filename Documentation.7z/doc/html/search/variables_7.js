var searchData=
[
  ['mail_5fmax_5fline_5flength_886',['MAIL_MAX_LINE_LENGTH',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#a6502202b02c243b5ceb4281c1ac36a0b',1,'PHPMailer::PHPMailer::PHPMailer']]],
  ['max_5fline_5flength_887',['MAX_LINE_LENGTH',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#a466169b7248c947b2d0d468a955573e7',1,'PHPMailer\PHPMailer\PHPMailer\MAX_LINE_LENGTH()'],['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_s_m_t_p.html#a466169b7248c947b2d0d468a955573e7',1,'PHPMailer\PHPMailer\SMTP\MAX_LINE_LENGTH()']]],
  ['max_5freply_5flength_888',['MAX_REPLY_LENGTH',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_s_m_t_p.html#a59dc88994da310e530d378c50b12870b',1,'PHPMailer::PHPMailer::SMTP']]]
];
