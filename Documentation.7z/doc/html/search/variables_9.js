var searchData=
[
  ['version_893',['VERSION',['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_h_p_mailer.html#af71005841ce53adac00581ab0ba24c1f',1,'PHPMailer\PHPMailer\PHPMailer\VERSION()'],['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_p_o_p3.html#af71005841ce53adac00581ab0ba24c1f',1,'PHPMailer\PHPMailer\POP3\VERSION()'],['../class_p_h_p_mailer_1_1_p_h_p_mailer_1_1_s_m_t_p.html#af71005841ce53adac00581ab0ba24c1f',1,'PHPMailer\PHPMailer\SMTP\VERSION()']]]
];
